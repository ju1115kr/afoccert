(function() {
    'use strict';
        window.api_url ='http://54.1.1.94:5000/api/v1.0';
        window.test_version = false;
})();
