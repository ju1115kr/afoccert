'use strict';

angular.module('certApp', [
    'ngResource',
    'ngRoute',
    'route-segment',
    'view-segment',
    'ngSanitize',
    'ngFileUpload',
    'ngAnimate',
    'ui.bootstrap',
    'utilsModule'
]);
