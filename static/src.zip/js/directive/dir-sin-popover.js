'use strict';

var app = angular.module('certApp');

app.directive("sinPopover", function(){

	
})